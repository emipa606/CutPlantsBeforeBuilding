﻿using RimWorld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace CutPlantsBeforeBuilding {
    [DefOf]
    public static class MyKeyBindingDefOf {
        public static KeyBindingDef TMB_ToggleAutoDesignatePlantsCutMode;
    }
}
